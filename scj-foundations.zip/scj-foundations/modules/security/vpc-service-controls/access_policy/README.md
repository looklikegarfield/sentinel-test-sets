# terraform-google-vpc-service-controls

This module handles opinionated VPC Service Controls and Access Context Manager configuration and deployments.

## Compatibility
This module is meant for use with Terraform 0.13. If you haven't
[upgraded](https://www.terraform.io/upgrade-guides/0-13.html) and need a Terraform
0.12.x-compatible version of this module, the last released version
intended for Terraform 0.12.x is [v2.1.0](https://registry.terraform.io/modules/terraform-google-modules/-vpc-service-controls/google/v2.1.0).

## Usage
This module handles the configuration of the [access_context_manager_policy resource](https://www.terraform.io/docs/providers/google/r/access_context_manager_access_policy.html). F

### Known limitations

The [Access Context Manager API](https://cloud.google.com/access-context-manager/docs/) guarantees that resources will be created, but there may be a delay between a successful response and the change taking effect. For example, ["after you create a service perimeter, it may take up to 30 minutes for the changes to propagate and take effect"](https://cloud.google.com/vpc-service-controls/docs/create-service-perimeters).
Because of these limitations in the API, you may first get an error when running `terraform apply` for the first time.
You can add a delay using terraform's [`null_resource`](https://www.terraform.io/docs/providers/null/resource.html).

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| parent\_id | The parent of this AccessPolicy in the Cloud Resource Hierarchy. As of now, only organization are accepted as parent. | `string` | n/a | yes |
| policy\_name | The policy's name. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| policy\_id | Resource name of the AccessPolicy. |
| policy\_name | The policy's name. |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

## Requirements

### Configure a Service Account

#### Organization level permissions
In order to create a policy, you need to grant your service account the Access Context Manager Admin role at the organization level:
- roles/accesscontextmanager.policyAdmin

You may use the following command:
`gcloud organizations add-iam-policy-binding ORGANIZATION_ID \
  --member="serviceAccount:example@project_id.iam.gserviceaccount.com" \
  --role="roles/accesscontextmanager.policyAdmin"`

### Configure user permission
In order to view VPC Service Controls and Access Context Manger using the Google Cloud Platform Console, your user accounts will need to be granted the Resource Manager Organization Viewer:
- roles/resourcemanager.organizationViewer

You may use the following command:
`gcloud projects add-iam-policy-binding <my project id> \
  --member="user:example@domain.com" \
  --role="roles/resourcemanager.organizationViewer"`

For more information see the [Access Context Manager ACL Page](https://cloud.google.com/access-context-manager/docs/access-control)


### Enable APIs
To use this module you must enable Access Context Manager API (accesscontextmanager.googleapis.com) on project.

In order to operate with the Service Account you must activate the following APIs on the project where the Service Account was created:

- Storage JSON API - storage-api.googleapis.com
- Big Query API - bigquery.googleapis.com

## Install

Be sure you have the correct Terraform version (0.12.x), you can choose the binary here:
- https://releases.hashicorp.com/terraform/