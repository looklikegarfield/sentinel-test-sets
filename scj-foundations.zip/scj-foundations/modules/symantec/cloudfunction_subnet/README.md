# `cloudfunction_subnet` Module

Creates and manages a subnet and a VPC access connector for deploying Cloud Functions.

## Deployment

Deploying this module requires a VPC and mandates specifying a `/28` netmask for the subnet, as required by Google.

Having created the resources with this module, pass the output value of the `vpc_connector_name` to the deployment of
log processor Cloud Functions using `--vpc-connector=$VPC_CONNECTOR_NAME`.

## Variables

### `network`

> **Type**: `string`   
> **Required**: ❗️

The VPC network name to create the subnet within.

### `region`

> **Type**: `string`   
> **Required**: ❗️

The region to deploy the subnet in.

### `resource_prefix`

> **Type**: `string`   
> **Default**: `abs`

A prefix used when creating resources. This value will be postfixed with a hyphen and joined with the rest of the
generated resource name for each relevant resource.

### `subnet_base_address`

> **Type**: `string`   
> **Required**: ❗️

The subnet base address to create. This will be combined with a `/28` netmask to create the subnet.

> **Example** 
> 
> `10.127.0.0` will yield `10.127.0.0/28`.

## Outputs

### `subnet_id`

> **Type**: `string`

The `self_link` of the created subnet.

### `subnet_cidr`

> **Type**: `string`

The CIDR range of the created subnet.

### `subnet_name`

> **Type**: `string`

The subnet name of the created subnet.

### `subnet_region`

> **Type**: `string`

The region of the created subnet.

### `vpc_connector_id`

> **Type**: `string`

The `self_link` of the created VPC connector.

### `vpc_connector_name`

> **Type**: `string`

The name of the created VPC connector.