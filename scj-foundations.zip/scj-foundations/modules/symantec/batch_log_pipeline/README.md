# `batch_log_pipeline` Module

Creates and manages required infrastructure for setting up a batch logging pipeline for syslog forwarding to Symantec
Log Collector platform VMs.

> **⚠️ WARNING ⚠️**: Reading the **deployment** section below is mandatory to avoid creation of exponential logging loops
> and generating massive backlogs and subsequent bills.

## Deployment

Before deploying, be aware of these potential side-effects that may occur when creating these resources:

> ⚠️ **Exponential Log Loops**: if the Cloud Function names are not passed to this module, every time one of these 
> Cloud Functions run, they will generate logs, which will be emitted into this pipeline, which will be processed by
> those Cloud Functions, which will generate logs, etc. causing a potentially infinite and exponential log generation 
> loop.

> ⚠️ **Infinite Backlog**: if the Cloud Function(s) are not attached to the topic and `enabled` is set to `true`, an
> infinite backlog will begin building within the PubSub topic.

> ⚠ **Billing**: costs will be incurred when enabling this pipeline; cost sources include number of PubSub events,
> bytes transmitted through PubSub, and Cloud Function execution time.

Deployment of this module will likely need to occur in _multiple phases_ to ensure that the above issues are not
encountered. If the name identifiers of the Cloud Function(s) are known in advance, declare them using the
`cloud_function_names` list variable at instantiation time, skip to phase 3.

### Phase 1: Disabled Deployment

The resources in this module can be created without enabling them. By default, the `enabled` variable is set to `false`
as a safety measure. Deploy these resources with `enabled` set to `false` to create the infrastructure without enabling
the pipeline.

### Phase 2: Create Cloud Function(s)

Next, create the Cloud Functions(s) for all relevant Symantec logging pipelines. See documentation in the `src`
directory of the Cloud Function for how to deploy the function, use the `topic_name` output as the trigger for the
deployed Cloud Function (`--trigger-topic=$TOPIC_NAME`).

### Phase 2: Set Cloud Function Name(s)

Update the deployment, passing the name(s) of the created Cloud Function(s) via `cloud_function_names` for exclusion. 
This will add the appropriate exclusion rules to the logging sink. At this point, anything pushed to the PubSub topic
will trigger the Cloud Function, but the sink itself will remain disabled. Now would be a good time to test things
before proceeding.

### Phase 3: Enable

Finally, set `enabled` to `true`, having created the Cloud Function(s), attached the batch processor function to the
PubSub topic, and having passed Cloud Function name(s) via `cloud_function_names` to prevent an exponential log loop.
At this point, logs will be emitted from the sink into the PubSub topic, which will trigger the attached Cloud Function,
processing log events.

## Variables

### `cloud_function_names`

> **Type**: `list(string)`   
> **Default**: `["abs-logs-symantec-batch-processor", "abs-logs-symantec-live-processor"]`

The names of the deployed Symantec log forwarder Cloud Functions. These **must** be passed in order to avoid creating an
exponential log generation loop. See the [Deployment](#deployment) section above for more information.

### `enabled`

> **Type**: `bool`   
> **Default**: `false`

Whether the logging sink is enabled (`true`) or disabled (`true`). By default, this is set to `false` to prevent
accidental deployment of the sink without having a Cloud Function attached to the topic.

### `log_filter`

> **Type**: `string`   
> **Default**: `null`

A logging _inclusion_ filter. Log events matching this filter will be included, but the exclusion filters have
precedence if the inclusion filter and an exclusion filter is matched. Consider this a "whitelist" for log events.

### `log_filter_exclusions`

> **Type**: `list(string)`   
> **Default**: `[]`

A list of log exclusion filters for preventing logs from being processed. In addition to these exclusion filters, the
`cloud_function_names` will be added as their own exclusion filter. Consider this a list of "blacklists" for log events.

### `org_id`

> **Type**: `string`   
> **Default**: `null`

When `org_sink` is set to `true`, this value must be passed with the ID of the organization to attach the logging sink
to.

### `org_sink`

> **Type**: `bool`   
> **Required** ❗️

Whether to create an _organization_ logging sink (`true`) or a _project_ logging sink (`false`). Creation of an
organization logging sink requires highly elevated permissions and ingests all logs from the organization, a project
sink only ingests logs from the current project.

### `resource_prefix`

> **Type**: `string`   
> **Default**: `abs`

A prefix used when creating resources. This value will be postfixed with a hyphen and joined with the rest of the
generated resource name for each relevant resource.

## Outputs

### `bucket_id`

> **Type**: `string`

The `self_link` to the batch log files bucket.

### `bucket_name`

> **Type**: `string`

The name of the batch log files bucket.

### `sink_id`

> **Type**: `string`

The organization or project logging sink ID. See the `org_sink` variable above.

### `sink_name`

> **Type**: `string`

The organization or project logging sink name. See the `org_sink` variable above.

### `sink_writer_identity`

> **Type**: `string`

The organization or project logging sink IAM writer identity. See the `org_sink` variable above.

### `topic_id`

> **Type**: `string`

The PubSub topic ID for bucket upload notifications

### `topic_name`

> **Type**: `string`

The PubSub topic name for bucket upload notifications.