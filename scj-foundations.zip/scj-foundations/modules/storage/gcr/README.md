# Terraform Google Container Registry Module

The module makes it easy to create a Google Container Registry for hosting container images.

## Compatibility

This module is meant for use with Terraform 0.14.9 or higher.

## Usage

Basic usage of this module is as follows:


```hcl
module "gcr" {
  source = "<path to deployment/modules/storage/gcr folder>"
  project_id = "<PROJECT ID>"
  location = "<GCS/GCR LOCATION>"
}
```
