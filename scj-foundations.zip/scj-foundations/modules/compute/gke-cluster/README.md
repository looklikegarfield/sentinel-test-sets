# GKE cluster module

This module allows simplified creation and management of GKE cluster, nodepool.. 

## Example

```hcl
module "nonprod_gke_cluster_01" {
  source                             = "../../../../modules/compute/gke-cluster/"
  project_id                         = "abs-tf-runner"
  region_name                        = "us-east4"
  network_name                       = "test-vpc1"
  name                               = "my-simple-cluster1"
  description                        = "This is a sample cluster"
  subnetwork                         = "test-subnet1"
  ip_range_pods                      = "s1secrange3"
  ip_range_services                  = "s1secrange2"
  service_account                    = "tf-runner@abs-tf-runner.iam.gserviceaccount.com"
  cloudrun                           = true
  enable_vertical_pod_autoscaling    = true
  horizontal_pod_autoscaling         = true
  regional                           = true
  enable_private_endpoint            = true
  enable_private_nodes               = true
  master_ipv4_cidr_block             = "172.16.0.0/28"
  default_max_pods_per_node          = 20
  remove_default_node_pool           = true
  enable_intranode_visibility        = true
  enable_binary_authorization        = true
  enable_network_egress_export       = true
  enable_resource_consumption_export = true
  resource_usage_export_dataset_id   = "test_gke_bq_dataset"
  config_connector                   = true
  dns_cache                          = true

  cluster_autoscaling = {
    enabled       = true
    max_cpu_cores = 1000
    min_cpu_cores = 10
    max_memory_gb = 300
    min_memory_gb = 15
  }

  node_pools = [
    {
      name              = "pool-01"
      min_count         = 1
      max_count         = 100
      local_ssd_count   = 0
      disk_size_gb      = 100
      disk_type         = "pd-standard"
      image_type        = "COS"
      auto_repair       = true
      auto_upgrade      = true
      service_account   = "tf-runner@abs-tf-runner.iam.gserviceaccount.com"
      preemptible       = false
      max_pods_per_node = 12
    },
  ]

  master_authorized_networks = [
    {
      cidr_block   = "10.0.1.0/24"
      display_name = "VPC"
    },
  ]

  cluster_resource_labels = {
    "mytestkey" = "mytestvalue"
    "key2"      = "spoke"
  }
}

```

## Variables

| name | description | type | required | default |
|---|---|:---: |:---:|:---:|
| name | Cluster name. | <code title="">string</code> | ✓ |  |
| regional | Whether is a regional cluster (zonal cluster if set false. WARNING: changing this after cluster creation is destructive!) | <code title="">string</code> |  |  yes |
| region_name | The region to host the cluster in (optional if zonal cluster / required if regional). | <code title="">string</code> | ✓ |  |
| zones | The zones to host the cluster in (optional if regional cluster / required if zonal). | <code title="">list(string)</code> |  | [] |
| nodepool_name | Node pool name. | <code title="">string</code> | ✓ |  |
| network_name | The VPC network to host the cluster in (required). | <code title="">string</code> | ✓ |  |
| network_project_id | The project ID of the shared VPC's host (for shared vpc support). | <code title="">string</code> |  | ""  |
| project_id | Cluster project id. | <code title="">string</code> | ✓ |  |
| kubernetes_version | The Kubernetes version of the masters. If set to 'latest' it will pull latest available version in the selected region. | <code title="">string</code> |  | latest |
| master_authorized_networks | List of master authorized networks. If none are provided, disallow external access (except the cluster node IPs, which GKE automatically whitelists). | <code title="">list(object({ cidr_block = string, display_name = string }))</code> |  | [] |
| subnetwork | The subnetwork to host the cluster in (required). | <code title="">string</code> | ✓ |  |
| description | Cluster description. | <code title="">string</code> |  | <code title="">null</code> |
|enable_vertical_pod_autoscaling | Vertical Pod Autoscaling automatically adjusts the resources of pods controlled by it | <code title="">bool</code> |  | false |
| network_policy | Enable network policy addon. | <code title="">bool</code> |  | <code title="">CALICO</code> |
| network_policy_provider | The network policy provider. | <code title="">string</code> |  | <code title="">null</code> |
| horizontal_pod_autoscaling | Enable horizontal pod autoscaling addon. | <code title="">bool</code> |  | true |
| http_load_balancing |Enable httpload balancer addon . | <code title="">bool</code> |  | true |
| maintenance_start_time | Time window specified for daily or recurring maintenance operations in RFC3339 format. | <code title="">string</code> | ✓ | 05:00  |
| maintenance_exclusions | List of maintenance exclusions. A cluster can have up to three. | <code title="">list(object({ name = string, start_time = string, end_time = string }))</code> |  | [] |
| ip_range_pods | The _name_ of the secondary subnet ip range to use for pods. | <code title="">string</code> | ✓ |  |
| ip_range_services | The _name_ of the secondary subnet range to use for services. | <code title="">string</code> | ✓ |  |
| remove_default_node_pool | Remove default node pool while setting up the cluster. | <code title="">bool</code> |  | false  |
| node_pools | List of maps containing node pools. | <code title="">list(map(string))</code> |  |  [ {name = "default-node-pool" }, ] |
| node_pools_labels | Map of maps containing node labels by node-pool name. | <code title="">map(map(string))</code> |  | { all = {}default-node-pool = {} } |
| node_pools_metadata | Map of maps containing node metadata by node-pool name. | <code title="">map(map(string))</code> |  | { all = {}default-node-pool = {} } |
| resource_usage_export_dataset_id | The ID of a BigQuery Dataset for using BigQuery as the destination of resource usage export. | <code title="">string</code> |  | "" |
| enable_network_egress_export | Whether to enable network egress metering for this cluster. If enabled, a daemonset will be created in the cluster to meter network egress traffic. | <code title="">bool</code> |  | false |
| cluster_autoscaling | Cluster autoscaling configuration. See [more details](https://cloud.google.com/kubernetes-engine/docs/reference/rest/v1beta1/projects.locations.clusters#clusterautoscaling) | <code title="">object({    enabled       = bool,   min_cpu_cores = number,  max_cpu_cores = number,  min_memory_gb = number,    max_memory_gb = number,  })</code> |  | { enabled = false, max_cpu_cores = 0,  min_cpu_cores = 0,  max_memory_gb = 0, min_memory_gb = 0 }  |
| node_pools_taints | Map of lists containing node taints by node-pool name. | <code title="">map(list(object({ key = string, value = string, effect = string })))</code> |  | { all  = [],  default-node-pool = [] } |
| node_pools_tags | Map of lists containing node network tags by node-pool name. | <code title="">map(list(string))</code> |  |  { all  = [],  default-node-pool = [] } |
| node_pools_oauth_scopes | Map of lists containing node oauth scopes by node-pool name. | <code title="">map(list(string))</code> |  | { all  = ["https://www.googleapis.com/auth/cloud-platform"],  default-node-pool = [] }  |
| upstream_nameservers | If specified, the values replace the nameservers taken by default from the node’s /etc/resolv.conf. | <code title="">list(string)</code> |  | [] |
| logging_service | The logging service that the cluster should write logs to. Available options include logging.googleapis.com, logging.googleapis.com/kubernetes (beta), and none. | <code title="">string</code> |  | logging.googleapis.com/kubernetes |
| monitoring_service | The monitoring service that the cluster should write metrics to. Automatically send metrics from pods in the cluster to the Google Cloud Monitoring API. VM metrics will be collected by Google Compute Engine regardless of this setting Available options include monitoring.googleapis.com, monitoring.googleapis.com/kubernetes (beta) and none. | <code title="">string</code> |  | <code title="">monitoring.googleapis.com/kubernetes</code> |
| service_account | The service account to run nodes as if not overridden in `node_pools`. The create_service_account variable default value (true) will cause a cluster-specific service account to be created. | <code title="">string</code> |  | <code title="">""</code> |
| basic_auth_username | The username to be used with Basic Authentication. An empty value will disable Basic Authentication, which is the recommended configuration. | <code title="">string</code> |  | <code title="">""</code> |
| basic_auth_password | The password to be used with Basic Authentication. | <code title="">string</code> |  | <code title="">""</code> |
| issue_client_certificate | Issues a client certificate to authenticate to the cluster endpoint. To maximize the security of your cluster, leave this option disabled. Client certificates don't automatically rotate and aren't easily revocable. WARNING: changing this after cluster creation is destructive!. | <code title="">bool</code> |  | <code title="">false</code> |
| cluster_ipv4_cidr | The IP address range of the kubernetes pods in this cluster. Default is an automatically assigned CIDR.. | <code title="">bool</code> | ✓ |  |
| cluster_resource_labels | The GCE resource labels (a map of key/value pairs) to be applied to the cluster | <code title="">map(string)</code> |  | <code title="">{}</code> |
| default_max_pods_per_node | The maximum number of pods to schedule per node. | <code title="">string</code> |  | 110 |
| deploy_using_private_endpoint | A toggle for Terraform and kubectl to connect to the master's internal IP address during deployment. | <code title="">bool</code> |  | true |
| enable_private_endpoint | Whether the master's internal IP address is used as the cluster endpoint. | <code title="">bool</code> |  | false |
| enable_private_nodes | Whether nodes have internal IP addresses only. | <code title="">bool</code> |  | false |
| master_ipv4_cidr_block | The IP range in CIDR notation to use for the hosted master network. | <code title="">string</code> |  | 10.0.0.0/28 |
| enable_intranode_visibility | Whether Intra-node visibility is enabled for this cluster. This makes same node pod to pod traffic visible for VPC network. | <code title="">bool</code> |  | false |
| enable_tpu | Enable Cloud TPU resources in the cluster. WARNING: changing this after cluster creation is destructive! | <code title="">bool</code> |  | false |
| master_global_access_enabled | Whether the cluster master is accessible globally (from any region) or only within the same region as the private endpoint. | <code title="">bool</code> |  | true |
| node_metadata | Specifies how node metadata is exposed to the workload running on the node. | <code title="">string</code> |  | GKE_METADATA_SERVER |
| database_encryption | Application-layer Secrets Encryption settings. The object format is {state = string, key_name = string}. Valid values of state are: \"ENCRYPTED\"; \"DECRYPTED\". key_name is the name of a CloudKMS key. | <code title="">list(object({ state = string, key_name = string }))</code> |  | [{  state = "DECRYPTED",  key_name = "" }] |
| identity_namespace | Workload Identity namespace. (Default value of `enabled` automatically sets project based namespace `[project_id].svc.id.goog`. | <code title="">string</code> |  | enabled |
| release_channel | The release channel of this cluster. Accepted values are `UNSPECIFIED`, `RAPID`, `REGULAR` and `STABLE`. | <code title="">string</code> |  | null |
| enable_shielded_nodes | Enable Shielded Nodes features on all nodes in this cluster. | <code title="">bool</code> |  | true |
| enable_binary_authorization | Enable BinAuthZ Admission controller. | <code title="">bool</code> |  | false |
| cloudrun | Enable CloudRun addon. | <code title="">bool</code> |  | false |
| cloudrun_load_balancer_type | Configure the Cloud Run load balancer type. External by default. Set to `LOAD_BALANCER_TYPE_INTERNAL` to configure as an internal load balancer. | <code title="">string</code> |  | "" |
| config_connector | Whether ConfigConnector is enabled for this cluster. | <code title="">bool</code> |  | false |
| dns_cache | The status of the NodeLocal DNSCache addon. | <code title="">bool</code> |  | false |
| istio | Enable Istio addon. | <code title="">bool</code> |  | false |
| istio_auth | The authentication type between services in Istio. | <code title="">string</code> |  | AUTH_MUTUAL_TLS |
| timeouts | This resource provides the following Timeouts configuration options: | <code title="">object({create = string, update = string, delete = string, read = string})</code> |  | { create = "45m", update = "45m", delete = "45m", read = 45m"} |



## Configure a Terraform Service Account

In order to execute this module you must have a Service Account with the following roles:

- container.serviceAgent (Kubernetes Engine Service Agent)
- roles/storage.objectAdmin (Storage Object Admin)

## Required permissions/roles

- The shared VPC will be deployed in host project and the gke will be deployed in service project.
- You can use shared VPC module in ../modules/vpc to grant the IAM permissions through terraform. Refer to shared VPC readme file for more information

## Roles to be granted on Subnets of Shared VPC

| Service account | Role | Subnet | 
|------|-------------|------|
| service-service-project-1-num@container-engine-robot.iam.gserviceaccount.com | Compute Network User | tier-1 | 
| service-project-1-num@cloudservices.gserviceaccount.com | Compute Network User | tier-1 | 
| service-service-project-2-num@container-engine-robot.iam.gserviceaccount.com | Compute Network User | tier-2 | 
| service-project-2-num@cloudservices.gserviceaccount.com | Compute Network User | tier-2 | 


## IAM role bindings to be done in the host project

| Member | Role | Resource | 
|------|-------------|------|
| service-service-project-num@container-engine-robot.iam.gserviceaccount.com | Network User | Specific subnet or whole host project | 
| service-service-project-num@container-engine-robot.iam.gserviceaccount.com | Host Service Agent User | GKE service account in the host project | 

- For more information on roles/permissions and configuration refer to [Setting up clusters with Shared VPC](https://cloud.google.com/kubernetes-engine/docs/how-to/cluster-shared-vpc#overview) .