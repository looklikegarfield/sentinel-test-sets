# Terraform Google Cloud DNS Module

This module makes it easy to create Google Cloud DNS zones of different types, and manage their records. It supports creating public, private, forwarding, service directory and peering zones.

The resources/services/activations/deletions that this module will create/trigger are:

- One `google_dns_managed_zone` for the zone
- Zero or more `google_dns_record_set` for the zone records

## Compatibility

 This module is meant for use with Terraform 0.12. If you haven't [upgraded](https://www.terraform.io/upgrade-guides/0-12.html) and need a Terraform 0.12.x-compatible version of this module, the last released version intended for Terraform 0.11.x is [1.0.0](https://registry.terraform.io/modules/terraform-google-modules/cloud-dns/google/1.0.0).

## Usage

Basic usage of this module for a private zone is as follows:

```hcl
module "dns-private-zone" {
  source            = "cloud-dns"
  version           = "3.0.0"
  project_id        = "my-project"
  dns_type          = "private"
  dns_name          = "example-com"
  dns_domain        = "example.com."
  region_name       = "us-west2"
  description       = "Test desc"
  network_names     = ["gcp-abs-dmz-prod-vpc-01", "default"]
  labels = {
    "key1" = "value1"
    "key2" = "value2"
  }
  
  recordsets = [
    {
      name    = ""
      type    = "NS"
      ttl     = 300
      records = [
        "127.0.0.1",
      ]
    },
    {
      name    = "localhost"
      type    = "A"
      ttl     = 300
      records = [
        "127.0.0.1",
      ]
    },
  ]
}

```



<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| default\_key\_specs\_key | Object containing default key signing specifications : algorithm, key_length, key_type, kind. Please see https://www.terraform.io/docs/providers/google/r/dns_managed_zone.html#dnssec_config for futhers details | `any` | `<map>` | no |
| default\_key\_specs\_zone | Object containing default zone signing specifications : algorithm, key_length, key_type, kind. Please see https://www.terraform.io/docs/providers/google/r/dns_managed_zone.html#dnssec_config for futhers details | `any` | `<map>` | no |
| description | zone description (shown in console) | `string` | `"Managed by Terraform"` | no |
| dnssec\_config | Object containing : kind, non_existence, state. Please see https://www.terraform.io/docs/providers/google/r/dns_managed_zone.html#dnssec_config for futhers details | `any` | `<map>` | no |
| dns\_domain | Zone domain, must end with a period. | string | n/a | yes |
| labels | A set of key/value label pairs to assign to this ManagedZone | `map` | `<map>` | no |
| dns\_name | Zone name, must be unique within the project. | `string` | n/a | yes |
| network\_names | Names of all the VC networks where this DNS will be assocaited with | list(string) | `<list>` | no |
| project\_id | Project id for the zone. | `string` | n/a | yes |
| peer\_project\_id | Project id of the peering VPC. | `string` | n/a | yes |
| peer\_network\_name | VPC network name of the peer project | `string` | n/a | yes |
| dns\_service\_namespace_name | Service directory namespace . Refer here for more infomration https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_directory_namespace#namespace_id | `string` | null | yes |
| dns\_service\_directory\_region | Service directory namespace region . Refer here for more infomration https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_directory_namespace#location | `string` | null | no |
| recordsets | List of DNS record objects to manage, in the standard terraform dns structure. | `list(object)` | `[]` | no |
| target\_name\_server\_addresses | List of target name servers for forwarding zone. | `list(string)` | `[]` | no |
| target\_network | Peering network. | `string` | `""` | no |
| dns\_type | Type of zone to create, valid values are 'public', 'private' | `string` | `"private"` | no |

## Outputs

| Name | Description |
|------|-------------|
| zone_type | The DNS zone type. |
| sd | The service directory . |
| dns_managed_zone | The DNS zone . |


<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

## Requirements

These sections describe requirements for using this module.

### Software

The following dependencies must be available:

- [Terraform][terraform] v0.12
- [Terraform Provider for GCP][terraform-provider-gcp] plugin v2.14

### Service Account

User or service account credentials with the following roles must be used to provision the resources of this module:

- DNS Administrator: `roles/dns.admin`


### APIs

A project with the following APIs enabled must be used to host the
resources of this module:

- Google Cloud DNS API: `dns.googleapis.com`


## Contributing


