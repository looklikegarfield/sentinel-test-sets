# Terraform Network Module

This module creates VPC networks and their subnets.

## Usage

Basic usage of this submodule is as follows:

```hcl
module "vpcs" {
  source = "<path-to-module>"

  project_id    = <project-id-for-vpcs>
  vpcs          = var.vpcs
}
}
```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| project\_id | The ID of the project where these VPCs will be created | `any` | n/a | yes |
| vpcs | Map containing configuration for the VPCs and their subnets. Note that the network_code field should be unique across VPCs. | `map(object({ network_code = string, shared_network = string, description = string, subnets = list(object({ name = string, function = string, region = string, primary_ip_range = string, configs = map(string), secondary_ip_ranges = list(object({ range_name = string, ip_cidr_range = string })) } )) }))` | n/a | no |

## Outputs

| Name | Description |
|------|-------------|
| vpc_networks | The VPC resources being created. It's a map indexed by the network_code values provided in var.vpcs. Keys are self_link, id, and network. |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->