# Terraform Network Module

This submodule is part of the the `terraform-google-network` module. It creates the cloud router .

It supports creating:

- Cloud Router within vpc network.

## Usage

Basic usages of this submodule is as follows:

```hcl
module "cloud-router" {
    source  = "/modules/networking/cloud-router"
    version = "~> 2.0.0"

    project_id                         = "<PROJECT ID>"
    network_name                       = "example-vpc"
    router_name                        = <Router Name>
    region_name                        = <Router Region>
    asn_number                         = "64514"
}

```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| project\_id | The ID of the project where Cloud NAT will be created | `any` | n/a | yes |
| router\_name | A unique readable cloud router name | `string` | n/a | yes |
| network_name | The name of the VPC network in which the cloud router reside | `string` | n/a | yes |
| region_name | The name of the region where the cloud router reside | `string` | n/a | yes |
| asn_number | The asn number for the cloud router.Local BGP Autonomous System Number (ASN). Must be an RFC6996 private ASN, either 16-bit or 32-bit. The value will be fixed for this router resource. All VPN tunnels that link to this router will have the same local ASN| `number` | n/a | yes |
| advertise_mode | User-specified flag to indicate which mode to use for advertisement. Default value is DEFAULT. Possible values are DEFAULT and CUSTOM | `string` | DEFAULT | no |
| advertised_groups | User-specified list of prefix groups to advertise in custom mode. This field can only be populated if advertiseMode is CUSTOM and is advertised to all peers of the router. These groups will be advertised in addition to any specified prefixes. Leave this field blank to advertise no custom groups. This enum field has the one valid value: ALL_SUBNETS | no |
|nat_manual_ips_count|How many custom NAT IPs should be used|`list(string)`|null|no|
|advertised_ip_ranges|User-specified list of individual IP ranges to advertise in custom mode. This field can only be populated if advertiseMode is CUSTOM and is advertised to all peers of the router. These IP ranges will be advertised in addition to any specified groups. Leave this field blank to advertise no custom IP ranges. Structure is documented below.|`list(object({range = string, description  = string}))`|[]|no|



## Outputs

| Name | Description |
|------|-------------|
| cloud_router | The created cloud router resources |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

### NAT Inputs



Example input tfvar file 

```hcl
project_id                  = "abs-tf-runner"
region_name                 = "us-west2"
network_name                = "gcp-abs-dmz-prod-vpc-01"
asn_number                  = "64514"
router_name                 = "gcp-abs-core-prod-uw2-rt-01"
advertise_mode              = "CUSTOM"
advertised_groups           = ["myprefix", "2ndprefix"]
advertised_ip_ranges        = [
  {
     range        = "10.0.1.0/25"
     description  = "Test desc for range 1"
  },
  {
  range        = "10.0.2.0/25"
  description  = "Test desc for range 2"
  }
]
}
```
