# Terraform Network Module

This submodule is part of the the `terraform-google-network` module. It creates the cloud NAT.

It supports creating:

- Cloud NAT within vpc network.

## Usage

Basic usages of this submodule is as follows:

```hcl
module "cloud-nat" {
    source  = "terraform-google-modules/network/google/modules/cloud-nat"
    version = "~> 2.0.0"

    project_id                         = "<PROJECT ID>"
    network_name                       = "example-vpc"
    nat_name                           = <NAT Name>
    router_name                        = <Router Name>
    region_name                        = <Router Region>
    nat_ip_allocate_option             = "AUTO_ONLY" 
    source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
    

```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| project\_id | The ID of the project where Cloud NAT will be created | `any` | n/a | yes |
| router\_name | A unique readable cloud router name | `string` | n/a | yes |
| network_name | The name of the VPC network in which the cloud router reside | `string` | n/a | yes |
| region_name | The name of the region where the cloud router reside | `string` | n/a | yes |
| nat_name | The name of the cloud NAT that will be provisioned | `string` | n/a | yes |
| nat_ip_allocate_option | How external IPs should be allocated for this NAT. Valid values are AUTO_ONLY for only allowing NAT IPs allocated by Google Cloud Platform, or MANUAL_ONLY for only user-allocated NAT IP addresses. Possible values are MANUAL_ONLY and AUTO_ONLY | `string` | AUTO_ONLY | no |
| source_subnetwork_ip_ranges_to_nat | How NAT should be configured per Subnetwork. If ALL_SUBNETWORKS_ALL_IP_RANGES, all of the IP ranges in every Subnetwork are allowed to Nat. If ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES, all of the primary IP ranges in every Subnetwork are allowed to Nat. LIST_OF_SUBNETWORKS: A list of Subnetworks are allowed to Nat (specified in the field subnetwork below). Note that if this field contains ALL_SUBNETWORKS_ALL_IP_RANGES or ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES, then there should not be any other RouterNat section in any Router for this network in this region. Possible values are ALL_SUBNETWORKS_ALL_IP_RANGES, ALL_SUBNETWORKS_ALL_PRIMARY_IP_RANGES, and LIST_OF_SUBNETWORKS | `string` | ALL_SUBNETWORKS_ALL_IP_RANGES | no |
|nat_manual_ips_count|How many custom NAT IPs should be used|`number`|0|no|
|nat_subnets|NAT Subnets. Valid Values for source_ip_ranges_to_nat are ALL_IP_RANGES, LIST_OF_SECONDARY_IP_RANGES, PRIMARY_IP_RANGE|`map(object({region_name = string, secondary_range_names = list(string), source_ip_ranges_to_nat = list(string)}))`|{}|no|
|min_ports_per_vm|Minimum number of ports allocated to a VM from this NAT.|`number`|null|no|
|udp_idle_timeout_sec|Timeout (in seconds) for UDP connections. Defaults to 30s if not set|`number`|null|no|
|icmp_idle_timeout_sec|Timeout (in seconds) for ICMP connections. Defaults to 30s if not set|`number`|null|no|
|tcp_established_idle_timeout_sec|Timeout (in seconds) for TCP established connections. Defaults to 1200s if not set.|`number`|null|no|
|tcp_transitory_idle_timeout_sec|Timeout (in seconds) for TCP transitory connections. Defaults to 30s if not set.|`number`|null|no|
|nat_log_enable|Indicates whether or not to export logs|`bool`|true|no|
|nnat_log_filter|Specifies the desired filtering of logs on this NAT. Possible values are ERRORS_ONLY, TRANSLATIONS_ONLY, and ALL|`string`|ALL|no|


## Outputs

| Name | Description |
|------|-------------|
| cloud_nat | The created cloud nat resources |
| cloud_nat_address | The public IPs of cloud nat |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

### NAT Inputs



Example input tfvar file 

```hcl
nat_name                           = "test-nat"
network_name                        = "gcp-abs-dmz-prod-vpc-01"
project_id                          = "abs-tf-runner"
router_name                         = "my-test-router"
region_name                         = "us-west2"
nat_ip_allocate_option              = "MANUAL_ONLY"
nat_manual_ips_count                = 2
tcp_established_idle_timeout_sec    = 1400
source_subnetwork_ip_ranges_to_nat  = "LIST_OF_SUBNETWORKS"
nat_subnets              = {
   # test-subnet1	 = {
   #    region_name = "us-east4"
   #    secondary_range_names = []
   #    source_ip_ranges_to_nat = ["ALL_IP_RANGES"]
   # }
   test-subnet2	 = {
      region_name = "us-west2"
      secondary_range_names = ["s1secrange2", "s2secrange1"]
      source_ip_ranges_to_nat = ["LIST_OF_SECONDARY_IP_RANGES"]
   }
}
```
